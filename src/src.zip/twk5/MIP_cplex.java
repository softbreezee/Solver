package twk5;
/////////////////////////////////////////////////////////////////////////////
//
//
//Created:               120818 Xue Zhaojie
//1st version Finished:  120818 Xue Zhaojie
//Modified:              120821 Xue Zhaojie
//
//
//
//////////////////////////////////////////////////////////////////////////////

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.StringTokenizer;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import ilog.concert.*;
import ilog.cplex.*;

public class MIP_cplex 
    {

	int numofPickup = 0;
	int numofDelivery = 0;
	int numofCustomers = 0;
	int numofTasks = 0;
	int numofTractors = 0;
	double timePeriod = 0;

	double c1 = 0;
	double c2 = 0;
	double c3 = 0;

	double[] packageTime;
	double[][] distanceMatrix;

	double[][] coordinateofTerminal;
	double[][] coordinateofCustomer;

	int tractorLB = 0;
	static int instanceIndex = 0;

	int excelIndex = 0;
	int timeIndex = 0;

	public MIP_cplex(int dataindex, int tractorlb) throws IOException 
                 {
		fileInput(dataindex);
		tractorLB = tractorlb;
		// c1 = k;
		// excelIndex = w;
		// timeIndex = time;
		instanceIndex = dataindex;
		// fileOutput(packTime);
	        }

	private static final class TimestampOutput	extends IloCplex.MIPInfoCallback
                {

		private final Double start;

		public TimestampOutput(Double start) 
                              {
			this.start = start;
		              }

		public void main() throws IloException 
                      {
//			System.out.println(String.format("%.3f", (System.currentTimeMillis() - start)/1000)
//					+" " + String.format("%.3f", getIncumbentObjValue()) + " " + String.format("%.3f", getBestObjValue()) + " " + String.format("%.2f", 100*getMIPRelativeGap()));
			
			try {
				 FileWriter fw = new FileWriter("data/gaplog/cplex/gaplogfile" + instanceIndex +".txt", true);
				 PrintWriter pw = new PrintWriter(fw);
				
				//
				pw.println(String.format("%.3f",
						(System.currentTimeMillis() - start) / 1000)
						+ " "
						+ String.format("%.3f", getIncumbentObjValue())
						+ " "
						+ String.format("%.3f", getBestObjValue())
						+ " "
						+ String.format("%.2f", 100 * getMIPRelativeGap()));

				pw.flush();
				pw.close();
			    } 
                        catch (IOException e) 
                            {
				// TODO Auto-generated catch block
				e.printStackTrace();
			    }
		
		      }
      }

	public void maincplex() throws FileNotFoundException
     {

		try {

			// c1 = 10;
			// c2 = 1;
			// c3 = 0;
			// timePeriod = 24;
			// Build model
			IloCplex model = new IloCplex();

			 OutputStream os = new FileOutputStream(
			 "data/cplexlog/noshare/logfile_cplex"
			 + instanceIndex + ".csv");
			 model.setOut(os);
//			model.setOut(null);
//			model.setOut(new TimestampOutput());
			
//			model.use(new TimestampOutput((double)System.currentTimeMillis()));

			model.setParam(IloCplex.IntParam.MIPEmphasis, 0);

			model.setParam(IloCplex.IntParam.MIPDisplay, 2);
			model.setParam(IloCplex.IntParam.MIPInterval, 10000);

			model.setParam(IloCplex.DoubleParam.TiLim, 18000);

			// out of memory
			model.setParam(IloCplex.DoubleParam.WorkMem, 4096);
			// model.setParam(IloCplex.DoubleParam.TreLim, 3);
			model.setParam(IloCplex.IntParam.NodeFileInd, 3);
			model.setParam(IloCplex.StringParam.WorkDir, "data/result/out of memory");

			// Set the maximum number of threads to 1.
//			model.setParam(IloCplex.IntParam.Threads, 1);

			// model.setParam(IloCplex.DoubleParam.EpGap, 0);

			// no preprocessing
//			model.setParam(IloCplex.BooleanParam.PreInd, false);

			// Turn on traditional search for use with control callbacks
//			 model.setParam(IloCplex.IntParam.MIPSearch,
//			 IloCplex.MIPSearch.Traditional);
			//
			// model.setParam(IloCplex.IntParam.VarSel, 3);

			// ��������tij�����ʽһ��
			IloIntVar[][] xij = new IloIntVar[numofTasks + 1][numofTasks + 1];
			// IloNumVar[][] xij = new IloNumVar[numofTasks + 1][numofTasks +
			// 1];
			IloNumVar[] si = new IloNumVar[numofTasks];

			// ������߱���
			for (int i = 0; i < xij.length; i++) {
				for (int j = 0; j < xij[0].length; j++) {
					xij[i][j] = model.boolVar("X" + i + j);
				}
			}

			// xij�������ɳڰ汾
			// for (int i = 0; i < xij.length; i++) {
			// for (int j = 0; j < xij[0].length; j++) {
			// xij[i][j] = model.numVar(0,1,"X" + i + j);
			// }
			// }

			for (int i = 0; i < numofCustomers; i++) {
				si[i] = model.numVar(distanceMatrix[0][i + 1], timePeriod
						- distanceMatrix[i + 1][0] - packageTime[i], "s"
						+ (i + 1));
			}
			for (int i = numofCustomers; i < si.length; i++) {
				si[i] = model.numVar(distanceMatrix[0][i - numofCustomers + 1]
						+ packageTime[i - numofCustomers], timePeriod
						- distanceMatrix[i + 1][0], "s" + (i + 1));
			}

			// ����Լ��
			// Լ��1 network flow constraint
			for (int j = 1; j < numofTasks + 1; j++) {
				IloLinearNumExpr con1 = model.linearNumExpr();
				for (int i = 0; i < numofTasks + 1; i++) {
					if (i != j) {
						con1.addTerm(1.0, xij[i][j]);
					}
				}
				model.addEq(con1, 1);
			}

			// Լ��2 network flow constraint
			for (int i = 1; i < numofTasks + 1; i++) {
				IloLinearNumExpr con2 = model.linearNumExpr();
				for (int j = 0; j < numofTasks + 1; j++) {
					if (i != j) {
						con2.addTerm(1.0, xij[i][j]);
					}
				}
				model.addEq(con2, 1);
			}

			// Լ��3 sequence constraint
			// by logical constraints
			for (int i = 1; i < numofTasks + 1; i++) {
				for (int j = 1; j < numofTasks + 1; j++) {
					if (i != j && (i + numofCustomers) != j
					// && (i - numofCustomers) != j
					) {
						IloLinearNumExpr con3 = model.linearNumExpr();
						con3.addTerm(-1.0, si[i - 1]);
						con3.addTerm(1.0, si[j - 1]);
						model.add(model.ifThen(model.eq(xij[i][j], 1),
								model.ge(con3, distanceMatrix[i][j])));
					}
				}
			}

			// by big-M
			// for (int i = 1; i < numofTasks + 1; i++) {
			// for (int j = 1; j < numofTasks+1; j++) {
			// if (i != j && (i+numofCustomers)!=j && (i-numofCustomers)!=j) {
			// IloLinearNumExpr con3 = model.linearNumExpr();
			// con3.addTerm(1.0, si[i-1]);
			// con3.addTerm(-1.0, si[j-1]);
			// con3.addTerm(1000, xij[i][j]);
			// model.addLe(con3, 1000-distanceMatrix[i][j]);
			// }
			// }
			// }
			// for (int i = 1; i < numofTasks+1; i++) {
			// IloLinearNumExpr con3 = model.linearNumExpr();
			// con3.addTerm(1.0, si[i-1]);
			// con3.addTerm(-1.0, si[si.length - 1]);
			// con3.addTerm(1000, xij[i][0]);
			// model.addLe(con3, 1000-distanceMatrix[i][0]);
			// }

			// Լ��4 temporal constraint
			for (int i = 0; i < numofCustomers; i++) {
				IloLinearNumExpr con4 = model.linearNumExpr();
				con4.addTerm(1.0, si[numofCustomers + i]);
				con4.addTerm(-1.0, si[i]);
				model.addGe(con4, packageTime[i]);
			}

			// Լ��5 ���ӳ���Լ��
			IloLinearNumExpr con5 = model.linearNumExpr();
			for (int j = 1; j < numofTasks + 1; j++) {
				con5.addTerm(1, xij[0][j]);
			}
			model.addGe(con5, tractorLB);

			// IloLinearNumExpr con6 = model.linearNumExpr();
			// for (int i = 1; i < numofTasks + 1; i++) {
			// con6.addTerm(1, xij[i][0]);
			// }
			// model.addGe(con6, tractorLB);
			//
			// IloLinearNumExpr con7 = model.linearNumExpr();
			// for (int i = 1; i < numofTasks + 1; i++) {
			// con7.addTerm(1, xij[i][0]);
			// con7.addTerm(-1, xij[0][i]);
			// }
			// model.addEq(con7, 0);

			// ����Ŀ�꺯��
			IloLinearNumExpr objfun = model.linearNumExpr(); //
			for (int j = 1; j < numofTasks + 1; j++) {
				objfun.addTerm(c1, xij[0][j]);
			}

			for (int i = 0; i < numofTasks + 1; i++) {
				for (int j = 0; j < numofTasks + 1; j++) {
					if (j != i) {
						objfun.addTerm(c2 * distanceMatrix[i][j], xij[i][j]);
					}
				}
			}

			// for (int i = 0; i < numofDelivery; i++) {
			// for (int j = 0; j < numofPickup; j++) {
			// objfun.addTerm(-c3, xij[1+numofCustomers+numofPickup+i][1+j]);
			// }
			// }

			model.addMinimize(objfun);

			// model.exportModel("D:/out.lp");

			// Solve model
			double starttime, endtime;
			starttime = System.currentTimeMillis();
			if (model.solve()) {

				endtime = System.currentTimeMillis();
				System.out
						.println("/////////////////////////////////////////////////////////////////////// cplex  instance"
								+ instanceIndex);
				double finalObj = model.getObjValue();
				double cpuTime = (endtime - starttime) / 1000;
				System.out.println("Solution status = " + model.getStatus());
				System.out.println("final objctive = " + finalObj);
				System.out.println("CPU time:	" + cpuTime);

				int[][] sxij = new int[xij.length][xij[0].length];
				for (int i = 0; i < sxij.length; i++) {
					for (int j = 0; j < sxij[0].length; j++) {
						if (i != j) {
							if (model.getValue(xij[i][j]) < 0.1) {
								sxij[i][j] = 0;
							} else {
								sxij[i][j] = 1;
							}
						} else {
							sxij[i][j] = 0;
						}
					}
				}

				// output fleet size
				int fleetSize = 0;
				for (int i = 1; i < numofTasks + 1; i++) {
					fleetSize += sxij[0][i];
				}
				System.out.println("fleet size:	" + fleetSize);

				// output total traveling time
				double totalTravelTime = 0;
				for (int i = 0; i < sxij.length; i++) {
					for (int j = 0; j < sxij[0].length; j++) {
						totalTravelTime += sxij[i][j] * distanceMatrix[i][j];
					}
				}
				System.out.println("Total Travel time:	" + totalTravelTime);

				// output saving containers
				// int savingContainers = 0;
				// for (int i = 0; i < numofDelivery; i++) {
				// for (int j = 0; j < numofPickup; j++) {
				// savingContainers += sxij[1 + numofCustomers
				// + numofPickup + i][1 + j];
				// }
				// }
				// System.out.print("\rsaving containers:	" + savingContainers
				// + "\r");

				// output routes
				// System.out.print("\rroutes:\r");
				// for (int i = 1; i < numofTasks + 1; i++) {
				// if (sxij[0][i] == 1) {
				// int temp = i;
				// System.out.print(0 + "---" + temp);
				// do {
				// for (int j = 0; j < numofTasks + 1; j++) {
				// if (sxij[temp][j] == 1) {
				// temp = j;
				// System.out.print("---" + temp);
				// break;
				// }
				// }
				// } while (temp != 0);
				// System.out.print("\r");
				// }
				// }

				// output xij
				// System.out.print("\rxij:\r");
				// for (int i = 0; i < sxij.length; i++) {
				// for (int j = 0; j < sxij[0].length; j++) {
				// System.out.print(sxij[i][j] + "  ");
				// }
				// System.out.print("\r");
				// }

				// System.out.print("\rservice beginning time:\r");
				// for (int i = 0; i < numofTasks; i++) {
				// System.out.print(model.getValue(si[i]) //i + 1 + ": " +
				// + "\r");
				// }

				// /////////////////////////////////////noshre���ݼ�������������excel�ļ�
				 try {
				 // Excel����ļ�
				 Workbook wb = Workbook.getWorkbook(new java.io.File(
				 "data/result/noshare.xls"));
				 // ��һ���ļ��ĸ���������ָ������д�ص�ԭ�ļ�
				 WritableWorkbook book = Workbook.createWorkbook(
				 new java.io.File(
				 "data/result/noshare.xls"), wb);
				 // ���ɹ�����������0��ʾ���ǵ�һҳ
				 WritableSheet sheet = book.getSheet("noshare");
				 // ��Label����Ĺ�������ָ����Ԫ��λ���ǵ�һ�е�һ��(0,0)
				 // Label label = new Label(0, 0, "c1");
				 // // ������õĵ�Ԫ�����ӵ���������
				 // sheet.addCell(label);
				
				 // ������
				 jxl.write.Number number = new jxl.write.Number(2, instanceIndex+1, finalObj);
				 sheet.addCell(number);
				
				 number = new jxl.write.Number(3, instanceIndex+1, fleetSize);
				 sheet.addCell(number);
				
				 number = new jxl.write.Number(4, instanceIndex+1, totalTravelTime);
				 sheet.addCell(number);
				
				 // д�����ݲ��ر��ļ�
				 book.write();
				 book.close();
				 } catch (Exception e) {
				 System.out.println(e);
				 }

				// ////////////////////////////////////////////��ͬrho��ֵ�ļ�������������excel�ļ�
				// try {
				// // Excel����ļ�
				// Workbook wb = Workbook.getWorkbook(new java.io.File(
				// "data/result/rho ratio/rho.xls"));
				// // ��һ���ļ��ĸ���������ָ������д�ص�ԭ�ļ�
				// WritableWorkbook book = Workbook.createWorkbook(
				// new java.io.File(
				// "data/result/rho ratio/rho.xls"), wb);
				// // ���ɹ�����������0��ʾ���ǵ�һҳ
				// WritableSheet sheet = book.getSheet("rho");
				// // ��Label����Ĺ�������ָ����Ԫ��λ���ǵ�һ�е�һ��(0,0)
				// // Label label = new Label(0, 0, "c1");
				// // // ������õĵ�Ԫ�����ӵ���������
				// // sheet.addCell(label);
				//
				// // ������
				// jxl.write.Number number = new jxl.write.Number(2,
				// (int)excelIndex+1, fleetSize);
				// sheet.addCell(number);
				//
				// number = new jxl.write.Number(3, (int)excelIndex+1,
				// totalTravelTime);
				// sheet.addCell(number);
				//
				// number = new jxl.write.Number(4, (int)excelIndex+1,
				// finalObj);
				// sheet.addCell(number);
				//
				// // д�����ݲ��ر��ļ�
				// book.write();
				// book.close();
				// } catch (Exception e) {
				// System.out.println(e);
				// }

				// //////////////////////////////////////////��ͬw-k��������excel�ļ�
				// try {
				// // Excel����ļ�
				// Workbook wb = Workbook.getWorkbook(new java.io.File(
				// "data/result/w-k/wk-"+(int)c1+".xls"));
				// // ��һ���ļ��ĸ���������ָ������д�ص�ԭ�ļ�
				// WritableWorkbook book = Workbook.createWorkbook(
				// new java.io.File("data/result/w-k/wk-"+(int)c1+".xls"),
				// wb);
				// // ���ɹ�����������0��ʾ���ǵ�һҳ
				// WritableSheet sheet = book.getSheet("wk");
				// // ��Label����Ĺ�������ָ����Ԫ��λ���ǵ�һ�е�һ��(0,0)
				// // Label label = new Label(0, 0, "c1");
				// // // ������õĵ�Ԫ�����ӵ���������
				// // sheet.addCell(label);
				//
				// // ������
				// jxl.write.Number number = new jxl.write.Number(timeIndex+1,
				// (int) excelIndex + 2, finalObj);
				// sheet.addCell(number);
				//
				// number = new jxl.write.Number(timeIndex+1, (int) excelIndex +
				// 32,
				// fleetSize);
				// sheet.addCell(number);
				//
				// number = new jxl.write.Number(timeIndex+1, (int) excelIndex +
				// 62,
				// totalTravelTime);
				// sheet.addCell(number);
				//
				// // д�����ݲ��ر��ļ�
				// book.write();
				// book.close();
				// } catch (Exception e) {
				// System.out.println(e);
				// }

			} else {
				System.out.println("heihei��there are something wrong������������������");
			}
			model.end();
		} catch (IloException ex) {
			System.out.println("Concert Error: " + ex);
		}
	}

	private void fileInput(int dataindex) throws IOException {

//		String inputFilePath = "data/data/datafile" + dataindex + ".txt";
		String inputFilePath = "data/noshare data/noshare datafile" + dataindex + ".txt";
		// ����cluster�����ļ�
		// String inputFilePath = "data/clusterdata/datafile" + pickup + "-"
		// + delivery + ".txt";
		// ����ĳȷ���ļ������в�ͬrho��������
		// String inputFilePath = "data/rho ratio data/datafile4-4-4.5.txt";
		BufferedReader br = new BufferedReader(new FileReader(inputFilePath));

		// �����������
		br.readLine();
		String str = br.readLine();
		StringTokenizer st = new StringTokenizer(str);
		numofPickup = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		numofDelivery = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		numofCustomers = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		numofTasks = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		numofTractors = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		c1 = Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		c2 = Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		c3 = Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		timePeriod = Double.parseDouble(st.nextToken());

		packageTime = new double[numofCustomers];
		distanceMatrix = new double[numofTasks + numofTractors][numofTasks
				+ numofTractors];

		coordinateofTerminal = new double[1][2];
		coordinateofCustomer = new double[numofCustomers][2];

		// ����package time;
		br.readLine();
		for (int i = 0; i < numofCustomers; i++) {
			str = br.readLine();
			st = new StringTokenizer(str);
			packageTime[i] = Double.parseDouble(st.nextToken());
		}

		// ����terminal coordinate
		br.readLine();
		for (int i = 0; i < 2; i++) {
			str = br.readLine();
			st = new StringTokenizer(str);
			coordinateofTerminal[0][i] = Double.parseDouble(st.nextToken());
		}

		// ����customers coordinate
		br.readLine();
		for (int i = 0; i < coordinateofCustomer[0].length; i++) {
			for (int j = 0; j < coordinateofCustomer.length; j++) {
				str = br.readLine();
				st = new StringTokenizer(str);
				coordinateofCustomer[j][i] = Double.parseDouble(st.nextToken());
			}
		}

		// ����distance Matrix;
		br.readLine();
		for (int i = 0; i < distanceMatrix.length; i++) {
			for (int j = 0; j < distanceMatrix[0].length; j++) {
				str = br.readLine();
				st = new StringTokenizer(str);
				distanceMatrix[i][j] = Double.parseDouble(st.nextToken());
			}
		}

		// �޸�packaging time
		// packageTime = newPackageTime.clone();
		// for (int i = 0; i < packageTime.length; i++) {
		// packageTime[i] = packTime + 0.5 * Math.random();
		// packageTime[i] = myRound(packageTime[i], 3);
		// }

		// �����Ϊ��file���޸ĵ�����꣬����ͨ���������distanceMatrix
		// for (int i = 0; i < numofTractors; i++) {
		// for (int j = 0; j < numofTractors; j++) {
		// distanceMatrix[i][j] = 0;
		// }
		// for (int j = 0; j < numofCustomers; j++) {
		// distanceMatrix[i][numofTractors + j] =
		// distanceMatrix[i][numofTractors
		// + numofCustomers + j] = distance(
		// coordinateofTerminal[0][0], coordinateofTerminal[0][1],
		// coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
		// distanceMatrix[numofTractors + j][i] = distanceMatrix[numofTractors
		// + numofCustomers + j][i] = distance(
		// coordinateofTerminal[0][0], coordinateofTerminal[0][1],
		// coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
		// }
		// }
		//
		// for (int i = 0; i < numofCustomers; i++) {
		// for (int j = 0; j < numofCustomers; j++) {
		// distanceMatrix[i + numofTractors][j + numofTractors] =
		// distanceMatrix[numofTractors
		// + numofCustomers + i][j + numofTractors] =
		// distanceMatrix[numofTractors
		// + numofCustomers + i][numofTractors + numofCustomers
		// + j] = distance(coordinateofTerminal[0][0],
		// coordinateofTerminal[0][1], coordinateofCustomer[i][0],
		// coordinateofCustomer[i][1])
		// + distance(coordinateofTerminal[0][0],
		// coordinateofTerminal[0][1],
		// coordinateofCustomer[j][0],
		// coordinateofCustomer[j][1]);
		// distanceMatrix[i + numofTractors][numofTractors
		// + numofCustomers + j] = distance(
		// coordinateofCustomer[i][0], coordinateofCustomer[i][1],
		// coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
		// }
		// }
		//
		// for (int i = 0; i < numofDelivery; i++) {
		// for (int j = 0; j < numofPickup; j++) {
		// distanceMatrix[numofTractors + numofCustomers + numofPickup +
		// i][numofTractors
		// + j] = distance(
		// coordinateofCustomer[numofPickup + i][0],
		// coordinateofCustomer[numofPickup + i][1],
		// coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
		// }
		// }
		//
		// for (int i = 0; i < distanceMatrix.length; i++) {
		// for (int j = 0; j < distanceMatrix[0].length; j++) {
		// distanceMatrix[i][j] = distanceMatrix[i][j] / 80;
		// }
		// }
		//
		// for (int i = 0; i < numofCustomers; i++) {
		// distanceMatrix[numofTractors + numofCustomers + i][numofTractors
		// + i] = 1000;
		// }
		//
		// for (int i = 0; i < distanceMatrix.length; i++) {
		// for (int j = 0; j < distanceMatrix[0].length; j++) {
		// distanceMatrix[i][j] = myRound(distanceMatrix[i][j], 1);
		// }
		// }

		br.close();
	}

	// ������뺯��
	public double distance(double x1, double y1, double x2, double y2) {
		double truckspeed = 1; // /���忨����ʻ�ٶ�
		double dis = Math
				.sqrt((Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2)))
				/ truckspeed;
		return dis;
	}

	// ����С����λ������
	public static double myRound(double v, int scale) {
		String temp = "#0.";
		for (int i = 0; i < scale; i++) {
			temp += "0";
		}
		return Double.valueOf(new java.text.DecimalFormat(temp).format(v))
				.doubleValue();
	}

	public void fileOutput(double packTime) throws IOException {
		String outputFilePath = "data/data/different packing time/temp"
				+ (int) packTime + ".txt";
		FileWriter fw = new FileWriter(outputFilePath);

		// �����������
		fw.write("# of pickup customers\r\n" + numofPickup + "\r\n");
		fw.write("# of delivery customers\r\n" + numofDelivery + "\r\n");
		fw.write("# of customers\r\n" + numofCustomers + "\r\n");
		fw.write("# of tasks\r\n" + numofTasks + "\r\n");
		fw.write("# of given tractors\r\n" + numofTractors + "\r\n");
		fw.write("c1\r\n" + c1 + "\r\n");
		fw.write("c2\r\n" + c2 + "\r\n");
		fw.write("c3\r\n" + c3 + "\r\n");
		fw.write("timeperiod\r\n" + timePeriod + "\r\n");

		// ���package time;
		fw.write("package time\r\n");
		for (int i = 0; i < numofCustomers; i++) {
			fw.write(packageTime[i] + "\r\n");
		}

		// ���coordinates of terminal;
		fw.write("terminal coordinates\r\n");
		fw.write(coordinateofTerminal[0][0] + "\r\n");
		fw.write(coordinateofTerminal[0][1] + "\r\n");

		// ���coordinate of customers; ���ж���
		fw.write("customer coordinate\r\n");
		for (int i = 0; i < coordinateofCustomer[0].length; i++) {
			for (int j = 0; j < coordinateofCustomer.length; j++) {
				fw.write(coordinateofCustomer[j][i] + "\r\n");
			}
		}

		// ���distance matrix;
		fw.write("distance matrix\r\n");
		for (int i = 0; i < distanceMatrix.length; i++) {
			for (int j = 0; j < distanceMatrix[0].length; j++) {
				fw.write(distanceMatrix[i][j] + "\r\n");
			}
		}

		fw.write("ENDDATA\r\n");
		fw.flush();
		fw.close();
	}
}