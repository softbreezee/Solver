package twk5;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Map;

import org.junit.Test;

import ilog.concert.IloException;
import ilog.concert.IloIntVar;
import ilog.concert.IloLinearNumExpr;
import ilog.concert.IloNumVar;
import ilog.cplex.IloCplex;
import ref.ComputeUtil;
import ref.Data;

public class TWKSovler {
	Data d;
	/**
	 * 1、从d中取出的任务应该是子任务的数量
	 * 2、d.driveTime没有处理，应该是定义的弧转换时间
	 * 3、假设4个客户任务（第一阶段任务与第二阶段任务）的对应关系是
	 * 0->4
	 * 1->5
	 * 2->6
	 * 3->7
	 * 4、
	 * @throws FileNotFoundException
	 */

	@Test
	public void maincplex(){

		try {

			/**
			 * 数据处理
			 */
			d = new Data(501);
			Map<String, Object> map = ComputeUtil.Twk5Condition(d);
//			double[][] driveTimes = (double[][]) map.get("driveTimes");
			double[][] tij = (double[][]) map.get("tij");
			// c1 = 10;
			// c2 = 1;
			// c3 = 0;
			int timePeriod = 24*60;
			int tasks = d.taskNum*2;
			
			/**
			 * 建立模型
			 */
			// Build cplex
			IloCplex cplex = new IloCplex();
			

			/*此处删去对cplex的设置及cplex输出为一个cvs文件*/
			
			// 和文章中tij表格格式一致,这里的任务数量应该是【子】任务数量
			IloIntVar[][] X = new IloIntVar[tasks + d.stockNum][tasks + d.stockNum];
			// IloNumVar[][] xij = new IloNumVar[numofTasks + 1][numofTasks +
			// 1];
			IloNumVar[] Y = new IloNumVar[tasks];

			// 定义决策变量
			for (int i = 0; i < X.length; i++) {
				for (int j = 0; j < X[0].length; j++) {
					//boolVar里面的String参数是标识？
					X[i][j] = cplex.boolVar("X" + i + j);
				}
			}


			// xij连续，松弛版本
			// for (int i = 0; i < xij.length; i++) {
			// for (int j = 0; j < xij[0].length; j++) {
//			 xij[i][j] = cplex.numVar(0,1,"X" + i + j);
			// }
			// }

			for (int i = 0; i < tasks/2; i++) {
				Y[i] = cplex.numVar(tij[0][i + 1], timePeriod - tij[i + 1][0] - d.loadTime[i],
						"s" + (i + 1));
			}
			for (int i = tasks/2; i < Y.length; i++) {
				Y[i] = cplex.numVar(tij[0][i - d.taskNum + 1] + d.loadTime[i - d.taskNum],
						timePeriod - tij[i + 1][0], "s" + (i + 1));
			}

			// 定义约束
			//堆场车辆约束
			for(int i = 0;i<d.stockNum;i++){
				IloLinearNumExpr exprCar0 = cplex.linearNumExpr();//创建一个约束表达式
				for(int j = d.stockNum;j<tasks+d.stockNum;j++){
					if(i!=j){
						exprCar0.addTerm(1.0, X[i][j]);
					}
				}
				cplex.addLe(exprCar0, d.truckNum[i]);//添加约束表达式
			}
			
			
			// 流平衡约束
			for (int j = d.stockNum; j < d.stockNum + tasks; j++) {
				IloLinearNumExpr exprBal0 = cplex.linearNumExpr();
				IloLinearNumExpr exprBal1 = cplex.linearNumExpr();
				for (int i = 0; i < d.stockNum + tasks; i++) {
					if (i != j) {
						exprBal0.addTerm(1.0, X[i][j]);
						exprBal1.addTerm(1.0, X[j][i]);
					}
				}
				cplex.addEq(exprBal0, 1);
				cplex.addEq(exprBal0, exprBal1);
			}


			// 约束3 sequence constraint连续任务的节点时间顺序
			// by logical constraints
			// Yi - Yj + tij <= M(1-X[i][j])
			for (int i = d.stockNum; i < d.stockNum + tasks; i++) {
				for (int j = d.stockNum; j < d.stockNum + tasks ; j++) {
					if (i != j //&& (i + numofCustomers) != j
					// && (i - numofCustomers) != j
					) {
						IloLinearNumExpr con3 = cplex.linearNumExpr();
						con3.addTerm(-1.0, Y[i - d.stockNum]);
						con3.addTerm(1.0, Y[j - d.stockNum]);
						//ifThen(con1,con2):Returns a constraint that if con1 is true, then con2 must also be true.
						//con3 = Yj - Yi
						//Yj-Yi >=tij
						//if Xij被选中，那么Yj - Yi >= tij
						//tij用处理么？不用处理，因为刚好与之一一对应
						cplex.add(cplex.ifThen(cplex.eq(X[i][j], 1), cplex.ge(con3, tij[i][j])));
						
					}
				}
			}

			
			// by big-M
			// for (int i = 1; i < numofTasks + 1; i++) {
			// for (int j = 1; j < numofTasks+1; j++) {
			// if (i != j && (i+numofCustomers)!=j && (i-numofCustomers)!=j) {
			// IloLinearNumExpr con3 = cplex.linearNumExpr();
			// con3.addTerm(1.0, si[i-1]);
			// con3.addTerm(-1.0, si[j-1]);
			// con3.addTerm(1000, xij[i][j]);
			// cplex.addLe(con3, 1000-distanceMatrix[i][j]);
			// }
			// }
			// }
			// for (int i = 1; i < numofTasks+1; i++) {
			// IloLinearNumExpr con3 = cplex.linearNumExpr();
			// con3.addTerm(1.0, si[i-1]);
			// con3.addTerm(-1.0, si[si.length - 1]);
			// con3.addTerm(1000, xij[i][0]);
			// cplex.addLe(con3, 1000-distanceMatrix[i][0]);
			// }

			// 约束4 temporal constraint
			// d.taskNum>>1 是客户数量
			for (int i = 0; i < (tasks>>1); i++) {
				IloLinearNumExpr con4 = cplex.linearNumExpr();
				con4.addTerm(1.0, Y[(tasks>>1) + i]);
				con4.addTerm(-1.0, Y[i]);
				cplex.addGe(con4, d.loadTime[i]);
			}

			// 约束5 附加车数约束
//			IloLinearNumExpr con5 = cplex.linearNumExpr();
//			for (int j = 1; j < numofTasks + 1; j++) {
//				con5.addTerm(1, xij[0][j]);
//			}
//			cplex.addGe(con5, tractorLB);

			// IloLinearNumExpr con6 = cplex.linearNumExpr();
			// for (int i = 1; i < numofTasks + 1; i++) {
			// con6.addTerm(1, xij[i][0]);
			// }
			// cplex.addGe(con6, tractorLB);
			//
			// IloLinearNumExpr con7 = cplex.linearNumExpr();
			// for (int i = 1; i < numofTasks + 1; i++) {
			// con7.addTerm(1, xij[i][0]);
			// con7.addTerm(-1, xij[0][i]);
			// }
			// cplex.addEq(con7, 0);

			// 定义目标函数
			IloLinearNumExpr exprObj = cplex.linearNumExpr(); //

			for (int i = 0; i < tasks + d.stockNum; i++) {
				for (int j = 0; j < tasks + d.stockNum; j++) {
					if (j != i) {
						exprObj.addTerm(tij[i][j], X[i][j]);
					}
				}
			}

			// for (int i = 0; i < numofDelivery; i++) {
			// for (int j = 0; j < numofPickup; j++) {
			// objfun.addTerm(-c3, xij[1+numofCustomers+numofPickup+i][1+j]);
			// }
			// }

			cplex.addMinimize(exprObj);

			// cplex.exportcplex("D:/out.lp");

			// Solve cplex
			double starttime, endtime;
			starttime = System.currentTimeMillis();
			if (cplex.solve()) {

				endtime = System.currentTimeMillis();
				double finalObj = cplex.getObjValue();
				double cpuTime = (endtime - starttime) / 1000;
				System.out.println("Solution status = " + cplex.getStatus());
				System.out.println("final objctive = " + finalObj);
				System.out.println("CPU time:	" + cpuTime);

				int[][] sxij = new int[X.length][X[0].length];
				for (int i = 0; i < sxij.length; i++) {
					for (int j = 0; j < sxij[0].length; j++) {
						if (i != j) {
							if (cplex.getValue(X[i][j]) < 0.1) {
								sxij[i][j] = 0;
							} else {
								sxij[i][j] = 1;
							}
						} else {
							sxij[i][j] = 0;
						}
					}
				}

				// output fleet size
				int fleetSize = 0;
				for(int i = 0;i<d.stockNum;i++ ){
					for (int j = d.stockNum; j < tasks + d.stockNum; j++) {
						fleetSize += sxij[i][j];
					}
				}
				System.out.println("fleet size:	" + fleetSize);

				// output total traveling time
				double totalTravelTime = 0;
				for (int i = 0; i < sxij.length; i++) {
					for (int j = 0; j < sxij[0].length; j++) {
						totalTravelTime += sxij[i][j] * tij[i][j];
					}
				}
				System.out.println("Total Travel time:	" + totalTravelTime);

				// output saving containers
				// int savingContainers = 0;
				// for (int i = 0; i < numofDelivery; i++) {
				// for (int j = 0; j < numofPickup; j++) {
				// savingContainers += sxij[1 + numofCustomers
				// + numofPickup + i][1 + j];
				// }
				// }
				// System.out.print("\rsaving containers: " + savingContainers
				// + "\r");

				// output routes
				 System.out.print("\rroutes:\r");
				 for (int i = 1; i < tasks + 1; i++) {
				 if (sxij[0][i] == 1) {
				 int temp = i;
				 System.out.print(0 + "---" + temp);
				 do {
				 for (int j = 0; j < tasks + 1; j++) {
				 if (sxij[temp][j] == 1) {
				 temp = j;
				 System.out.print("---" + temp);
				 break;
				 }
				 }
				 } while (temp != 0);
				 System.out.print("\r");
				 }
				 }

				 //output xij
				 System.out.print("\rxij:\r");
				 for (int i = 0; i < sxij.length; i++) {
				 for (int j = 0; j < sxij[0].length; j++) {
				 System.out.print(sxij[i][j] + " ");
				 }
				 System.out.print("\r");
				 }

				 System.out.print("\rservice beginning time:\r");
				 for (int i = 0; i < tasks; i++) {
				 System.out.print(cplex.getValue(Y[i]) //i + 1 + ": " +
				 + "\r");
				 }

			}
			cplex.end();
		} catch (IloException ex) {
			System.out.println("Concert Error: " + ex);
		}
	}

}
