package twt2;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * 根据condition对象创建初始的数据，是否需要保存在数据库中！
 * 方案一
 * 不保存，则不能查看这些数据，或者说算例不能二次创建
 * 
 * 方案二
 * 保存，可以查看修改这些数据，可是创建二次算例
 * 
 * 2017、8、6号，开发停滞在第二时间窗的处理，要求行驶时间。第二时间窗是按照任务的顺序来生成。
 * 但是行驶时间矩阵是按照港口、堆场、客户的顺序生成的。
 * 客户不一定与任务的个数相等！
 * 客户点一定等于重箱任务的的个数！客户点只会在生成的时候出现重合的可能！
 * 但是客户点不一定是按照IE OE IF OF顺序排列的！！
 * 
 * 解决办法：暂时查看别人的生成初始信息的程序改进，完成后台方案一二！
 * @author Leon
 */
public class RandomCreate {
	private static RandomCreate create;
	
	int clientNum;
	int taskNum;
	int LOADTIME = 5;
	int[][] clientP;
	int[][] portP ;
	int[][] stockP ;
	double[][] distance ;
	double[][] driveTime ;
	
	int[][] tw1;
	int[][] tw2 ;
	int[] loadTime ;
	// 顶点活动时间
	double[] serviceTime;
	// 任务顶点活动时间
	double[][] nodeTW ;
	// 弧转换时间
	double[][] transTime;
	

	static {
		create = new RandomCreate();
	}

	/**
	 * 静态方法，提供一个map集合 封装信息： 
	 * 客户位置
	 * 港口位置
	 * 堆场位置
	 * 距离矩阵
	 * 时间矩阵
	 * 第一时间窗（taskNum） 
	 * 第二时间窗(IF+OF)
	 * 装卸货时间
	 * 距离矩阵(portNum+stockNum+taskNum)
	 * 
	 * @param ep
	 * @param ep
	 * @return
	 */
	public  void getCondition(int IE,int OE,int IF,int OF,int portNum,int stockNum,int rangeX,int rangeY) {

		clientNum = IF+OF;
		taskNum = IE+OE+IF+OF;
		LOADTIME = 5;
		clientP = create.getPosition(clientNum,rangeX,rangeY);
		portP = create.getPosition(portNum,rangeX, rangeY);
		stockP = create.getPosition(stockNum,rangeX, rangeY);
		distance = create.getDis(clientP, stockP, portP);
		driveTime = create.getDriveTime(distance);
		Map<String, Object> tw = create.getTW(IE,OE,IF,OF,portNum,stockNum, distance);
		tw1 = (int[][]) tw.get("tw1");
		tw2 = (int[][]) tw.get("tw2");
		loadTime = create.getLoadTime(IF,OF);
		// 顶点活动时间
		serviceTime = new double[taskNum];
		// 任务顶点活动时间
		nodeTW = new double[2][taskNum];
		// 弧转换时间
		transTime = new double[taskNum + stockNum][taskNum + stockNum];
		// 生成图的顶点时间
		create.condition(taskNum, IE, OE, IF, portNum, stockNum, LOADTIME, loadTime, tw1, tw2, driveTime, serviceTime, nodeTW, transTime);
	}


	//行驶时间矩阵
	private double[][] getDriveTime(double[][] distance) {
		double[][] driveTime = new double[distance[0].length][distance[0].length];
		for (int i = 0; i < distance[0].length; i++) {
			for (int j = i; j < distance[0].length; j++) {
				driveTime[i][j] = myRound(distance[i][j]/300,2);
				driveTime[j][i] = myRound(driveTime[i][j],2);
			}
		}
		
		return driveTime;
	}


	/**
	 * 时间窗问题：1、范围2、行驶的时间
	 * 
	 * @param IE
	 * @param OE
	 * @param IF
	 * @param OF
	 * @param rangeOfClient
	 * @param rangeOfstock
	 */
	private Map<String, Object> getTW(int IENum,int OENum,int IFNum,int OFNum,int portNum,int stockNum,double[][] distance) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		// 第一时间窗
		int taskNum = IENum+ IFNum + OENum + OFNum;
		int[][] tw1 = new int[2][taskNum];
		// 注意：：随机数应该乘的是范围！！
		for (int i = 0; i < taskNum; i++) {
			//第一时间窗是8：00 - 12：00，宽度是0-3小时
			tw1[0][i] = (int) (Math.random() * 240);
			tw1[1][i] = tw1[0][i] + (int) (Math.random() * 180);
		}
		map.put("tw1", tw1);

		// 第二时间窗,只有重箱任务有第二时间窗
		int num = OFNum + IFNum;
		int[][] tw2 = new int[2][num];
		// 注意：：随机数应该乘的是范围！！
		for (int i = 0; i < num; i++) {
			// 第二时间窗的开始时刻为第一时间窗的开始时刻+客户点与港口之间的行驶距离
			tw2[0][i] = tw1[0][i + taskNum - num] +(int)(distance[0][i+portNum+stockNum]/500) ;
			//宽度是2-5小时
			tw2[1][i] = tw2[0][i] + (int) (Math.random() * 180+120);
		}
		map.put("tw2", tw2);

		return map;
	}
	
	
	/**
	 * 生成初始位置
	 */
	private int[][] getPosition(int Num, int RangeOfX, int RangeOfY) {
		int[][] arr = new int[2][Num];
		for (int i = 0; i < Num; i++) {
			arr[0][i] = (int) (Math.random() * RangeOfX);
			arr[1][i] = (int) (Math.random() * RangeOfY);
		}
		return arr;
	}
	
	
	/**
	 * 生成距离矩阵
	 */
	private double[][] getDis(int[][] client, int[][] stock, int[][] port) {

		int clientNum = 0;
		if (client != null) {
			clientNum = client[0].length;
		}

		int num = clientNum + stock[0].length + port[0].length;
		double[][] dis = new double[num][num];
		// 港口、堆场、客户点
		// 生成距离矩阵
		for (int i = 0; i < num; i++) {
			for (int j = i; j < num; j++) {
				if (i < port[0].length) {
					if (j < port[0].length) {
						double x = Math.pow(port[0][i] - port[0][j], 2);
						double y = Math.pow(port[1][i] - port[1][j], 2);
						dis[i][j] = Math.pow(x + y, 0.5);
					}
					if (j >= port[0].length
							&& j < stock[0].length + port[0].length) {
						double x = Math.pow(port[0][i] - stock[0][j - port[0].length], 2);
						double y = Math.pow(port[1][i] - stock[1][j - port[0].length], 2);
						dis[i][j] = Math.pow(x + y, 0.5);
					}
					if (j >= stock[0].length + port[0].length) {
						double x = Math.pow(port[0][i] - client[0][j - stock[0].length - port[0].length], 2);
						double y = Math.pow(port[1][i] - client[1][j - stock[0].length - port[0].length], 2);
						dis[i][j] = Math.pow(x + y, 0.5);
					}

				}

				if (i >= port[0].length && i < stock[0].length + port[0].length) {
					if (j >= port[0].length && j < stock[0].length + port[0].length) {
						double x = Math.pow(stock[0][i - port[0].length] - stock[0][j - port[0].length], 2);
						double y = Math.pow(stock[1][i - port[0].length]- stock[1][j - port[0].length], 2);
						dis[i][j] = Math.pow(x + y, 0.5);
					}
					if (j >= stock[0].length + port[0].length) {
						double x = Math.pow(stock[0][i - port[0].length] - client[0][j - stock[0].length - port[0].length], 2);
						double y = Math.pow(stock[1][i - port[0].length] - client[1][j - stock[0].length - port[0].length], 2);
						dis[i][j] = Math.pow(x + y, 0.5);
					}

				}

				if (i >= stock[0].length + port[0].length
						&& j >= stock[0].length + port[0].length) {
					double x = Math.pow(client[0][i - stock[0].length - port[0].length] - client[0][j - stock[0].length - port[0].length],2);
					double y = Math.pow(client[1][i - stock[0].length - port[0].length] - client[1][j - stock[0].length - port[0].length],2);
					dis[i][j] = Math.pow(x + y, 0.5);
				}
				dis[j][i] = dis[i][j];
			}
		}

		return dis;

	}

	/**
	 * 生成装卸时间
	 *  --只有重箱任务有装卸货时间（第一次修改）
	 */
	private int[] getLoadTime(int IFNum,int OFNum) {
		int num =IFNum+ OFNum;
//		int num =ep.getIFNum() +ep.getIENum()+ ep.getOFNum()+ep.getOENum();
		int[] loadTime = new int[num];
		for (int i = 0; i < num; i++) {
			loadTime[i] = (int) (Math.random() * 15 + 5);
		}
		return loadTime;
	}
	
	public static void condition(int taskNum, int IENum, int OENum, int IFNum,
			int portNum, int stockNum, final int LOADTIME, int[] loadTime2,
			int[][] tw1, int[][] tw2, double[][] driveTime,
			double[] serviceTime, double[][] nodeTW, double[][] transTime) {
		/**
		 * 服务时间
		 * ie，oe，if,of
		 */
		for (int i = 0; i < taskNum; i++) {
			// i属于IE+OE
			if (i < (IENum + OENum)) {
				serviceTime[i] = LOADTIME;
			}
			// i属于IF
			if (i >= (IENum + OENum) && i < (IFNum + IENum + OENum)) {
				serviceTime[i] = (Math.max(
						(tw2[0][i - IENum - OENum] - tw1[1][i]),
						// 第一个客户就是if0对应的
						(LOADTIME + driveTime[0][i + stockNum + portNum - IENum
								- OENum]))
						+ loadTime2[i - IENum - OENum] + LOADTIME);
			}
			// i属于OF
			if (i >= (IFNum + IENum + OENum) && i < taskNum) {
				serviceTime[i] = (Math.max(
						(tw2[0][i - IENum - OENum] - tw1[1][i]), (loadTime2[i
								- IENum - OENum]
								+ LOADTIME + driveTime[i + stockNum + portNum
								- IENum - OENum][0])) + LOADTIME);
			}
		}

		/**
		 * 任务顶点的时间窗的开始时刻与结束时刻
		 * 
		 */
		for (int i = 0; i < taskNum; i++) {
			// i属于IE+OE
			if (i < (IENum + OENum)) {
				nodeTW[0][i] = tw1[0][i];
				nodeTW[1][i] = tw1[1][i];
			}
			// i属于IF
			if (i >= (IENum + OENum) && i < (IFNum + IENum + OENum)) {
				nodeTW[0][i] = Math.min(
						Math.max(tw1[0][i], tw2[0][i - IENum - OENum]
								- LOADTIME
								- driveTime[0][i - IENum - OENum + portNum
										+ stockNum]), tw1[1][i]);

				nodeTW[1][i] = Math.min(tw1[1][i], tw2[1][i - IENum - OENum]
						- LOADTIME
						- driveTime[0][i - IENum - OENum + portNum + stockNum]);
			}
			// i属于OF
			if (i >= (IFNum + IENum + OENum) && i < taskNum) {

				nodeTW[0][i] = Math.min(
						Math.max(tw1[0][i], tw2[0][i - IENum - OENum]
								- LOADTIME
								- driveTime[i + portNum + stockNum - IENum
										- OENum][0]
								- loadTime2[i - IENum - OENum]), tw1[1][i]);

				nodeTW[1][i] = Math.min(tw1[1][i], tw2[1][i - IENum - OENum]
						- LOADTIME
						- driveTime[i + portNum + stockNum - IENum - OENum][0]
						- loadTime2[i - IENum - OENum]);
			}
		}

		/**
		 * 装换时间Tij 从零开始先堆场，后任务
		 */
		double[] drive0 = Arrays.copyOfRange(driveTime[0], portNum, stockNum
				+ portNum);
		Arrays.sort(drive0);

		for (int i = 0; i < taskNum + stockNum; i++) {
			// i 属于 堆场
			if (i < stockNum) {
				for (int j = 0; j < taskNum + stockNum; j++) {
					// j属于 堆场
					if (j < stockNum) {
						transTime[i][j] = 0;
					}
					// j属于 OE
					else if (j >= stockNum + IENum
							&& j < stockNum + IENum + OENum) {
						transTime[i][j] = LOADTIME + driveTime[i + portNum][0];
					}
					// j属于 OF
					else if (j >= stockNum + IENum + OENum + IFNum
							&& j < taskNum + stockNum) {
						transTime[i][j] = LOADTIME
								* 2
								+ driveTime[i + portNum][j + portNum - IENum
										- OENum];
						// transTime[i][j] = LOADTIME * 2 + driveTime[i +
						// portNum][j + portNum];
					}
					// j属于 IF U IE
					else {
						transTime[i][j] = driveTime[i + portNum][0];
					}
				}
			}
			// i 属于 IE
			else if (i >= stockNum && i < stockNum + IENum) {
				for (int j = 0; j < taskNum + stockNum; j++) {
					// j属于 堆场
					if (j < stockNum) {
						transTime[i][j] = LOADTIME + driveTime[0][j + portNum];
					}
					// j属于 OE
					else if (j >= stockNum + IENum
							&& j < stockNum + IENum + OENum) {
						transTime[i][j] = 0;
					}
					// j属于 OF
					else if (j >= stockNum + IENum + OENum + IFNum
							&& j < taskNum + stockNum) {
						transTime[i][j] = LOADTIME
								+ driveTime[0][j + portNum - IENum - OENum];
						// transTime[i][j] = LOADTIME + driveTime[0][j + portNum
						// ];
					}
					// j属于 IF U IE
					else {
						transTime[i][j] = LOADTIME + drive0[0] * 2;
					}
				}
			}
			// i 属于 IF
			else if (i >= stockNum + IENum + OENum
					&& i < stockNum + IENum + OENum + IFNum) {
				for (int j = 0; j < taskNum + stockNum; j++) {
					// j属于 堆场
					if (j < stockNum) {
						transTime[i][j] = LOADTIME
								* 2
								+ driveTime[i + portNum - IENum - OENum][j
										+ portNum];
					}
					// j属于 OE
					else if (j >= stockNum + IENum
							&& j < stockNum + IENum + OENum) {
						transTime[i][j] = LOADTIME
								+ driveTime[i + portNum - IENum - OENum][0];
					}
					// j属于 OF
					else if (j >= stockNum + IENum + OENum + IFNum
							&& j < taskNum + stockNum) {
						if (driveTime[i + portNum - IENum - OENum][j + portNum
								- IENum - OENum] > 0) {
							transTime[i][j] = LOADTIME
									* 2
									+ driveTime[i + portNum - IENum - OENum][j
											+ portNum - IENum - OENum];
						} else {
							transTime[i][j] = 0;
						}
					}
					// j属于 IF U IE
					else {
						double[] ds = Arrays.copyOfRange(driveTime[i + portNum
								- IENum - OENum], portNum, stockNum + portNum);
						Arrays.sort(ds);
						transTime[i][j] = LOADTIME * 2 + ds[0] + drive0[0];
					}
				}

			}
			// i 属于 OF U OE
			else {
				for (int j = 0; j < taskNum + stockNum; j++) {

					// j属于 堆场
					if (j < stockNum) {
						transTime[i][j] = driveTime[0][j + portNum];
					}
					// j属于 OE
					else if (j >= stockNum + IENum
							&& j < stockNum + IENum + OENum) {
						transTime[i][j] = drive0[0] * 2 + LOADTIME;
					}
					// j属于 OF
					else if (j >= stockNum + IENum + OENum + IFNum
							&& j < taskNum + stockNum) {
						double[] ds = Arrays.copyOfRange(driveTime[j + portNum
								- IENum - OENum], portNum, stockNum + portNum);
						Arrays.sort(ds);
						transTime[i][j] = LOADTIME * 2 + ds[0] + drive0[0];
					}
					// j属于 IF U IE
					else {
						transTime[i][j] = 0;
					}
				}

			}
		}

	}
	
	// 保留小数点位数方法
	public static double myRound(double v, int scale) {
		String temp = "#0.";
		for (int i = 0; i < scale; i++) {
			temp += "0";
		}
		return Double.valueOf(new java.text.DecimalFormat(temp).format(v))
				.doubleValue();
	}
	
	// ///////// 写出自定义格式算例文件
	public void fileOutput() throws IOException {
//		String outputFilePath = "/datafile" + numofPickup + "-" + numofDelivery + ".txt";
		String outputFilePath = "D:/datafile" + numofPickup + "-" + numofDelivery + ".txt";
		FileWriter fw = new FileWriter(outputFilePath);

		// 输出基本参数
		fw.write("# of pickup customers\r\n" + numofPickup + "\r\n");
		fw.write("# of delivery customers\r\n" + numofDelivery + "\r\n");
		fw.write("# of customers\r\n" + numofCustomers + "\r\n");
		fw.write("# of tasks\r\n" + numofTasks + "\r\n");
		fw.write("# of given tractors\r\n" + numofTractors + "\r\n");
		fw.write("c1\r\n" + c1 + "\r\n");
		fw.write("c2\r\n" + c2 + "\r\n");
		fw.write("c3\r\n" + c3 + "\r\n");
		fw.write("timeperiod\r\n" + timePeriod + "\r\n");

		// 输出package time;
		fw.write("package time\r\n");
		for (int i = 0; i < numofCustomers; i++) {
			fw.write(packageTime[i] + "\r\n");
		}

		// 输出coordinates of terminal;
		fw.write("terminal coordinates\r\n");
		fw.write( coordinateofTerminal[0][0] + "\r\n");
		fw.write( coordinateofTerminal[0][1] + "\r\n");
		
		// 输出coordinate of customers; 按列读出
		fw.write("customer coordinate\r\n");
		for (int i = 0; i < coordinateofCustomer[0].length; i++) {
			for (int j = 0; j < coordinateofCustomer.length; j++) {
				fw.write(coordinateofCustomer[j][i] + "\r\n");
			}
		}

		// 输出distance matrix;
		fw.write("distance matrix\r\n");
		for (int i = 0; i < distanceMatrix.length; i++) {
			for (int j = 0; j < distanceMatrix[0].length; j++) {
				fw.write(distanceMatrix[i][j] + "\r\n");
			}
		}

		fw.write("ENDDATA\r\n");
		fw.flush();
		fw.close();
	}


}
