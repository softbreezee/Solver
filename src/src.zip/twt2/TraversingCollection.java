package twt2;

import java.util.ArrayList;

/**
 * 遍历集合中的任意一个子集
 * 例如｛012｝
 * 子集有
 * @author Leon
 *
 */
public class TraversingCollection {
	
	public void getSubSets(ArrayList<Integer> arr){
		
		for(int i=0;i<arr.size();i++){
			if(arr.contains(arr.get(i))){
				
			}
			
		}
		
	}
}
