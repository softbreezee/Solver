package twt2;
/////////////////////////////////////////////////////////////////////////////
//                                                       
//            
//     Created:               110118 Xue Zhaojie
//     1st version Finished:  110118 Xue Zhaojie
//     Modified:              110221 Xue Zhaojie
//			   
//  
//
//////////////////////////////////////////////////////////////////////////////

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.*;

import org.junit.Test;

/**
 * ������������
 * @author Leon
 *
 */
public class Generator {

	int ofNum = 0;//
	int ifNum = 0;//
	int ieNum = 0;//
	int oeNum = 0;//
	int numofCustomers = 0;
	int numofTasks = 0;
	int numofStock = 0;
	int numofPort = 0;
	double timePeriod = 0;
	double[][] firstTW;
	double[][] secondTW;


	double[] loadTime;
	double[][] driveTime;
	
	double[][] coordinateofTerminal;
	double[][] coordinateofCustomer;

	@Test
	public void test() throws IOException{
		Generator g = new Generator();
//		g.generate(2, 3, 2);
		g.fileOutput();
		
		
	}
	
	
	
	public void generate(int ofNum, int ifNum,int ieNum,int oeNum,int numofPort,int numofStock){
		this.ofNum = ofNum;
		this.ifNum = ifNum;

		numofCustomers = ifNum + ofNum;
		numofTasks = 2 * numofCustomers;
		this.numofStock = numofStock;


		timePeriod = 16;
		loadTime = new double[numofCustomers];
		tij = new double[numofTasks + numofStock][numofTasks
				+ numofStock];

		coordinateofTerminal = new double[1][2];
		coordinateofCustomer = new double[numofCustomers][2];

		// ��������
		double areaParameter = 200; // �����С����

		coordinateofTerminal[0][0] = areaParameter / 2;
		coordinateofTerminal[0][1] = areaParameter / 2;

		// ����customer����
		for (int i = 0; i < numofCustomers; i++) {
			coordinateofCustomer[i][0] = myRound(Math.random() * areaParameter,
					2);
			coordinateofCustomer[i][1] = myRound(Math.random() * areaParameter,
					2);
		}

		for (int i = 0; i < numofStock; i++) {
			for (int j = 0; j < numofStock; j++) {
				tij[i][j] = 0;
			}
			for (int j = 0; j < numofCustomers; j++) {
				tij[i][numofStock + j] = tij[i][numofStock
						+ numofCustomers + j] = distance(
						coordinateofTerminal[0][0], coordinateofTerminal[0][1],
						coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
				tij[numofStock + j][i] = tij[numofStock
						+ numofCustomers + j][i] = distance(
						coordinateofTerminal[0][0], coordinateofTerminal[0][1],
						coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
			}
		}

		for (int i = 0; i < numofCustomers; i++) {
			for (int j = 0; j < numofCustomers; j++) {
				tij[i + numofStock][j + numofStock] = tij[numofStock
						+ numofCustomers + i][j + numofStock] = tij[numofStock
						+ numofCustomers + i][numofStock + numofCustomers
						+ j] = distance(coordinateofTerminal[0][0],
						coordinateofTerminal[0][1], coordinateofCustomer[i][0],
						coordinateofCustomer[i][1])
						+ distance(coordinateofTerminal[0][0],
								coordinateofTerminal[0][1],
								coordinateofCustomer[j][0],
								coordinateofCustomer[j][1]);
				tij[i + numofStock][numofStock
						+ numofCustomers + j] = distance(
						coordinateofCustomer[i][0], coordinateofCustomer[i][1],
						coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
			}
		}

		for (int i = 0; i < ifNum; i++) {
			for (int j = 0; j < ofNum; j++) {
				tij[numofStock + numofCustomers + ofNum + i][numofStock
						+ j] = distance(
						coordinateofCustomer[ofNum + i][0],
						coordinateofCustomer[ofNum + i][1],
						coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
			}
		}

		for (int i = 0; i < tij.length; i++) {
			for (int j = 0; j < tij[0].length; j++) {
				tij[i][j] = tij[i][j] / 80;
			}
		}

		// ��������Ŷ���ʹ���粻�Գ�
//		 for (int i = 0; i < tij.length; i++) {
//		 for (int j = 0; j < tij.length; j++) {
//		 tij[i][j] = tij[i][j]
//		 * (0.9 + 0.2 * Math.random());
//		 }
//		 }

		for (int i = 0; i < numofCustomers; i++) {
			tij[numofStock + numofCustomers + i][numofStock
					+ i] = 1000;
		}

		for (int i = 0; i < tij.length; i++) {
			for (int j = 0; j < tij[0].length; j++) {
				tij[i][j] = myRound(tij[i][j], 3);
			}
		}

		for (int i = 0; i < loadTime.length; i++) {
			loadTime[i] = 3 + 2 * Math.random();
			loadTime[i] = myRound(loadTime[i], 3);
		}
		
		
	}
	
	
	
	
	public void generate(int ofNum, int ifNum) {

		this.ofNum = ofNum;
		this.ifNum = ifNum;

		numofCustomers = ifNum + ofNum;
		numofTasks = 2 * numofCustomers;
		numofStock = 1;


		timePeriod = 16;
		loadTime = new double[numofCustomers];
		tij = new double[numofTasks + numofStock][numofTasks
				+ numofStock];

		coordinateofTerminal = new double[1][2];
		coordinateofCustomer = new double[numofCustomers][2];

		// ��������
		double areaParameter = 200; // �����С����

		coordinateofTerminal[0][0] = areaParameter / 2;
		coordinateofTerminal[0][1] = areaParameter / 2;

		// ����customer����
		for (int i = 0; i < numofCustomers; i++) {
			coordinateofCustomer[i][0] = myRound(Math.random() * areaParameter,
					2);
			coordinateofCustomer[i][1] = myRound(Math.random() * areaParameter,
					2);
		}

		for (int i = 0; i < numofStock; i++) {
			for (int j = 0; j < numofStock; j++) {
				tij[i][j] = 0;
			}
			for (int j = 0; j < numofCustomers; j++) {
				tij[i][numofStock + j] = tij[i][numofStock
						+ numofCustomers + j] = distance(
						coordinateofTerminal[0][0], coordinateofTerminal[0][1],
						coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
				tij[numofStock + j][i] = tij[numofStock
						+ numofCustomers + j][i] = distance(
						coordinateofTerminal[0][0], coordinateofTerminal[0][1],
						coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
			}
		}

		for (int i = 0; i < numofCustomers; i++) {
			for (int j = 0; j < numofCustomers; j++) {
				tij[i + numofStock][j + numofStock] = tij[numofStock
						+ numofCustomers + i][j + numofStock] = tij[numofStock
						+ numofCustomers + i][numofStock + numofCustomers
						+ j] = distance(coordinateofTerminal[0][0],
						coordinateofTerminal[0][1], coordinateofCustomer[i][0],
						coordinateofCustomer[i][1])
						+ distance(coordinateofTerminal[0][0],
								coordinateofTerminal[0][1],
								coordinateofCustomer[j][0],
								coordinateofCustomer[j][1]);
				tij[i + numofStock][numofStock
						+ numofCustomers + j] = distance(
						coordinateofCustomer[i][0], coordinateofCustomer[i][1],
						coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
			}
		}

		for (int i = 0; i < ifNum; i++) {
			for (int j = 0; j < ofNum; j++) {
				tij[numofStock + numofCustomers + ofNum + i][numofStock
						+ j] = distance(
						coordinateofCustomer[ofNum + i][0],
						coordinateofCustomer[ofNum + i][1],
						coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
			}
		}

		for (int i = 0; i < tij.length; i++) {
			for (int j = 0; j < tij[0].length; j++) {
				tij[i][j] = tij[i][j] / 80;
			}
		}

		// ��������Ŷ���ʹ���粻�Գ�
//		 for (int i = 0; i < tij.length; i++) {
//		 for (int j = 0; j < tij.length; j++) {
//		 tij[i][j] = tij[i][j]
//		 * (0.9 + 0.2 * Math.random());
//		 }
//		 }

		for (int i = 0; i < numofCustomers; i++) {
			tij[numofStock + numofCustomers + i][numofStock
					+ i] = 1000;
		}

		for (int i = 0; i < tij.length; i++) {
			for (int j = 0; j < tij[0].length; j++) {
				tij[i][j] = myRound(tij[i][j], 3);
			}
		}

		for (int i = 0; i < loadTime.length; i++) {
			loadTime[i] = 3 + 2 * Math.random();
			loadTime[i] = myRound(loadTime[i], 3);
		}
	}


	// ///////// д���Զ����ʽ�����ļ�
	public void fileOutput() throws IOException {
//		String outputFilePath = "/datafile" + ofNum + "-" + ifNum + ".txt";
		String outputFilePath = "D:/datafile" + ofNum + "-" + ifNum + ".txt";
		FileWriter fw = new FileWriter(outputFilePath);

		// �����������
		fw.write("# of pickup customers\r\n" + ofNum + "\r\n");
		fw.write("# of delivery customers\r\n" + ifNum + "\r\n");
		fw.write("# of customers\r\n" + numofCustomers + "\r\n");
		fw.write("# of tasks\r\n" + numofTasks + "\r\n");
		fw.write("# of given tractors\r\n" + numofStock + "\r\n");
		fw.write("timeperiod\r\n" + timePeriod + "\r\n");

		// ���package time;
		fw.write("package time\r\n");
		for (int i = 0; i < numofCustomers; i++) {
			fw.write(loadTime[i] + "\r\n");
		}

		// ���coordinates of terminal;
		fw.write("terminal coordinates\r\n");
		fw.write( coordinateofTerminal[0][0] + "\r\n");
		fw.write( coordinateofTerminal[0][1] + "\r\n");
		
		// ���coordinate of customers; ���ж���
		fw.write("customer coordinate\r\n");
		for (int i = 0; i < coordinateofCustomer[0].length; i++) {
			for (int j = 0; j < coordinateofCustomer.length; j++) {
				fw.write(coordinateofCustomer[j][i] + "\r\n");
			}
		}

		// ���distance matrix;
		fw.write("distance matrix\r\n");
		for (int i = 0; i < tij.length; i++) {
			for (int j = 0; j < tij[0].length; j++) {
				fw.write(tij[i][j] + "\r\n");
			}
		}

		fw.write("ENDDATA\r\n");
		fw.flush();
		fw.close();
	}

	
	//
	// // //////////�������ļ���������,�ƶ�������������ȥʵ���ļ�����
	public void fileInput(int pickup, int delivery) throws IOException {

		String inputFilePath = "data/datafile" + pickup + "-" + delivery
				+ ".txt";
		BufferedReader br = new BufferedReader(new FileReader(inputFilePath));

		// �����������
		br.readLine();
		String str = br.readLine();
		StringTokenizer st = new StringTokenizer(str);
		ofNum = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		ifNum = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		numofCustomers = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		numofTasks = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		numofStock = (int) Double.parseDouble(st.nextToken());


		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		timePeriod = Double.parseDouble(st.nextToken());

		loadTime = new double[numofCustomers];
		tij = new double[numofTasks + numofStock][numofTasks
				+ numofStock];

		// ����package time;
		br.readLine();
		for (int i = 0; i < numofCustomers; i++) {
			str = br.readLine();
			st = new StringTokenizer(str);
			loadTime[i] = Double.parseDouble(st.nextToken());
		}

		// ����distance Matrix;
		br.readLine();
		for (int i = 0; i < tij.length; i++) {
			for (int j = 0; j < tij[0].length; j++) {
				str = br.readLine();
				st = new StringTokenizer(str);
				tij[i][j] = Double.parseDouble(st.nextToken());
			}
		}

		br.close();
	}

	// ������뺯��
	public double distance(double x1, double y1, double x2, double y2) {
		double truckspeed = 1; // /���忨����ʻ�ٶ�
		double dis = Math
				.sqrt((Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2)))
				/ truckspeed;
		return dis;
	}

	// ����С����λ������
	public static double myRound(double v, int scale) {
		String temp = "#0.";
		for (int i = 0; i < scale; i++) {
			temp += "0";
		}
		return Double.valueOf(new java.text.DecimalFormat(temp).format(v))
				.doubleValue();
	}
	
	void fileInput(Reader r) throws IOException {

//		String inputFilePath = "data/data/datafile" + dataindex + ".txt";
//		String inputFilePath = "data/noshare data/noshare datafile" + dataindex + ".txt";
		// ����cluster�����ļ�
		// String inputFilePath = "data/clusterdata/datafile" + pickup + "-"
		// + delivery + ".txt";
		// ����ĳȷ���ļ������в�ͬrho��������
		// String inputFilePath = "data/rho ratio data/datafile4-4-4.5.txt";
		BufferedReader br = new BufferedReader(r);

		// �����������
		br.readLine();
		String str = br.readLine();
		StringTokenizer st = new StringTokenizer(str);
		ofNum = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		ifNum = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		numofCustomers = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		numofTasks = (int) Double.parseDouble(st.nextToken());

		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		numofStock = (int) Double.parseDouble(st.nextToken());


		br.readLine();
		str = br.readLine();
		st = new StringTokenizer(str);
		timePeriod = Double.parseDouble(st.nextToken());

		loadTime = new double[numofCustomers];
		tij = new double[numofTasks + numofStock][numofTasks
				+ numofStock];

		coordinateofTerminal = new double[1][2];
		coordinateofCustomer = new double[numofCustomers][2];

		// ����package time;
		br.readLine();
		for (int i = 0; i < numofCustomers; i++) {
			str = br.readLine();
			st = new StringTokenizer(str);
			loadTime[i] = Double.parseDouble(st.nextToken());
		}

		// ����terminal coordinate
		br.readLine();
		for (int i = 0; i < 2; i++) {
			str = br.readLine();
			st = new StringTokenizer(str);
			coordinateofTerminal[0][i] = Double.parseDouble(st.nextToken());
		}

		// ����customers coordinate
		br.readLine();
		for (int i = 0; i < coordinateofCustomer[0].length; i++) {
			for (int j = 0; j < coordinateofCustomer.length; j++) {
				str = br.readLine();
				st = new StringTokenizer(str);
				coordinateofCustomer[j][i] = Double.parseDouble(st.nextToken());
			}
		}

		// ����distance Matrix;
		br.readLine();
		for (int i = 0; i < tij.length; i++) {
			for (int j = 0; j < tij[0].length; j++) {
				str = br.readLine();
				st = new StringTokenizer(str);
				tij[i][j] = Double.parseDouble(st.nextToken());
			}
		}

		// �޸�packaging time
		// loadTime = newloadTime.clone();
		// for (int i = 0; i < loadTime.length; i++) {
		// loadTime[i] = packTime + 0.5 * Math.random();
		// loadTime[i] = myRound(loadTime[i], 3);
		// }

		// �����Ϊ��file���޸ĵ�����꣬����ͨ���������tij
		// for (int i = 0; i < numofStock; i++) {
		// for (int j = 0; j < numofStock; j++) {
		// tij[i][j] = 0;
		// }
		// for (int j = 0; j < numofCustomers; j++) {
		// tij[i][numofStock + j] =
		// tij[i][numofStock
		// + numofCustomers + j] = distance(
		// coordinateofTerminal[0][0], coordinateofTerminal[0][1],
		// coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
		// tij[numofStock + j][i] = tij[numofStock
		// + numofCustomers + j][i] = distance(
		// coordinateofTerminal[0][0], coordinateofTerminal[0][1],
		// coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
		// }
		// }
		//
		// for (int i = 0; i < numofCustomers; i++) {
		// for (int j = 0; j < numofCustomers; j++) {
		// tij[i + numofStock][j + numofStock] =
		// tij[numofStock
		// + numofCustomers + i][j + numofStock] =
		// tij[numofStock
		// + numofCustomers + i][numofStock + numofCustomers
		// + j] = distance(coordinateofTerminal[0][0],
		// coordinateofTerminal[0][1], coordinateofCustomer[i][0],
		// coordinateofCustomer[i][1])
		// + distance(coordinateofTerminal[0][0],
		// coordinateofTerminal[0][1],
		// coordinateofCustomer[j][0],
		// coordinateofCustomer[j][1]);
		// tij[i + numofStock][numofStock
		// + numofCustomers + j] = distance(
		// coordinateofCustomer[i][0], coordinateofCustomer[i][1],
		// coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
		// }
		// }
		//
		// for (int i = 0; i < ifNum; i++) {
		// for (int j = 0; j < ofNum; j++) {
		// tij[numofStock + numofCustomers + ofNum +
		// i][numofStock
		// + j] = distance(
		// coordinateofCustomer[ofNum + i][0],
		// coordinateofCustomer[ofNum + i][1],
		// coordinateofCustomer[j][0], coordinateofCustomer[j][1]);
		// }
		// }
		//
		// for (int i = 0; i < tij.length; i++) {
		// for (int j = 0; j < tij[0].length; j++) {
		// tij[i][j] = tij[i][j] / 80;
		// }
		// }
		//
		// for (int i = 0; i < numofCustomers; i++) {
		// tij[numofStock + numofCustomers + i][numofStock
		// + i] = 1000;
		// }
		//
		// for (int i = 0; i < tij.length; i++) {
		// for (int j = 0; j < tij[0].length; j++) {
		// tij[i][j] = myRound(tij[i][j], 1);
		// }
		// }

		br.close();
	}
	
	
}
