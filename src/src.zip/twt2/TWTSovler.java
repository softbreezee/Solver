package twt2;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.cplex.IloCplex;
import ref.ComputeUtil;
import ref.Data;

/**
 * 计算工具,cplex
 * 
 * 任务的排列：IE OE IF OF ie0 ie1 ie2 oe0 oe1 if0 if1 of0 of1 of2 ...
 * DAOV图上的顶点排列顺序是出发/返回顶点、IE、OE、IF、OF
 * 
 * 实际中的顶点排列顺序是港口、堆场、客户
 * 
 * 重箱任务的数量要等于客户的数量！！
 * 
 * @author Leon
 * 
 */
public class TWTSovler {
	Data d;

	@Before
	public void be() {
		d = new Data(1);
	}

	@Test
	public void c0() {
		System.out.println((8>>1)+1);

	}

	@Test
	public void computing() {

		/**
		 * 2、条件，用来确定服务时间、顶点活动时间、顶点转换时间的值
		 */
		Map<String, Object> map = ComputeUtil.condition(d);
		double[] serviceTime = (double[]) map.get("serviceTime");
		double[][] nodeTW = (double[][]) map.get("nodeTW");
		double[][] transTime = (double[][]) map.get("transTime");

		/**
		 * 3、 数学模型
		 */

		try {
			IloCplex cplex = new IloCplex();
			int v = d.stockNum + d.stockNum;
			System.out.println(v);
			int c = d.taskNum;
			System.out.println(c);
			// 决策变量Xij
			IloNumVar[][] X = new IloNumVar[d.stockNum + d.taskNum][d.stockNum + d.taskNum];
			for (int i = 0; i < d.stockNum + d.taskNum; i++) {
				// 定义决策变量的范围
				// 每一个X[i]都有d.stockNum + d.taskNum个数
				X[i] = cplex.boolVarArray(d.stockNum + d.taskNum);

			}
			// 决策变量Yij
			IloNumVar[] Y = cplex.numVarArray(d.taskNum, 0, Integer.MAX_VALUE);
			// 定义决策Zij
			IloNumVar[][] Z = new IloNumVar[d.stockNum + d.taskNum][];
			for (int i = 0; i < d.stockNum + d.taskNum; i++) {
				Z[i] = cplex.numVarArray(d.stockNum + d.taskNum, 0, Integer.MAX_VALUE);
			}

			// 目标函数
			IloNumExpr[][] expr0 = new IloNumExpr[d.taskNum][d.stockNum];
			IloNumExpr[][] expr1 = new IloNumExpr[d.stockNum][d.taskNum];
			for (int i = 0; i < d.taskNum; i++) {
				for (int j = 0; j < d.stockNum; j++) {
					expr0[i][j] = cplex.sum(Z[i + d.stockNum][j],
							cplex.prod(transTime[i + d.stockNum][j], X[i + d.stockNum][j]));
				}
			}
			for (int i = 0; i < d.stockNum; i++) {
				for (int j = 0; j < d.taskNum; j++) {
					// if (i != j)
					expr1[i][j] = Z[i][j + d.stockNum];
				}
			}
			IloNumExpr[] expr2 = new IloNumExpr[d.taskNum];
			IloNumExpr[] expr3 = new IloNumExpr[d.stockNum];
			for (int i = 0; i < d.taskNum; i++) {
				expr2[i] = cplex.sum(expr0[i]);
			}
			for (int i = 0; i < d.stockNum; i++) {
				expr3[i] = cplex.sum(expr1[i]);
			}
			IloNumExpr exprObj = cplex.diff(cplex.sum(expr2), cplex.sum(expr3));
			// 目标函数
			// IloNumExpr[] expr0 = new IloNumExpr[d.taskNum];
			// for (int i = 0; i < d.taskNum; i++) {
			// IloNumExpr[] expr00 = new IloNumExpr[d.stockNum];
			// for (int j = 0; j < d.stockNum; j++) {
			// expr00[j] = cplex.sum(
			// Z[i + d.stockNum][j],
			// cplex.prod(transTime[i + d.stockNum][j], X[i + d.stockNum][j]));
			// }
			// expr0[i] = cplex.sum(expr00);
			// }
			// IloNumExpr exprObj = cplex.sum(expr0);

			// 车辆数约束
			IloNumExpr[][] tempCar0 = new IloNumExpr[d.stockNum][d.taskNum];
			for (int i = 0; i < d.stockNum; i++) {
				for (int j = 0; j < d.taskNum; j++) {
					tempCar0[i][j] = X[i][j + d.stockNum];
				}
			}
			IloNumExpr[] tempCar1 = new IloNumExpr[d.stockNum];
			for (int i = 0; i < d.stockNum; i++) {
				tempCar1[i] = cplex.sum(tempCar0[i]);
				cplex.addLe(tempCar1[i], d.truckNum[i]);
			}

			// 流平衡约束
			IloNumExpr[][] tempBal0 = new IloNumExpr[d.taskNum][d.taskNum + d.stockNum];
			IloNumExpr[] tempBal1 = new IloNumExpr[d.taskNum];
			IloNumExpr[] tempBal2 = new IloNumExpr[d.taskNum];
			for (int i = 0; i < d.taskNum; i++) {
				for (int j = 0; j < d.taskNum + d.stockNum; j++) {
					// a01 = x10
					// a02 = x20
					// a03 = x30
					tempBal0[i][j] = X[j][i + d.stockNum];
				}
			}
			for (int i = 0; i < d.taskNum; i++) {
				tempBal1[i] = cplex.sum(tempBal0[i]);
				tempBal2[i] = cplex.sum(X[i + d.stockNum]);
			}
			for (int i = 0; i < d.taskNum; i++) {
				cplex.addEq(tempBal1[i], tempBal2[i]);
				cplex.addEq(1, tempBal1[i]);
				cplex.addEq(1, tempBal2[i]);
			}

			// 时间窗约束
			for (int i = 0; i < d.taskNum; i++) {
				cplex.addLe(nodeTW[0][i], Y[i]);
				cplex.addLe(Y[i], nodeTW[1][i]);
			}

			// 时间连续性约束，serviceTimes只用d.taskNum个
			int M = Integer.MAX_VALUE;
			for (int i = 0; i < d.taskNum; i++) {
				for (int j = 0; j < d.taskNum + d.stockNum; j++) {
//					if (i != j) {
						// model.add(TB[i]+ET[i]+Tran_time[i][j]-TB[j]<=(1-X[i][j])*M);
						// model.add(y[i] +T[i] - Z[i][j]<=(1-X[i][j])M)
						cplex.addLe(cplex.diff(cplex.sum(Y[i], serviceTime[i]), Z[i + d.stockNum][j]),
								cplex.prod(M, cplex.diff(1, X[i + d.stockNum][j]))//
						);
//					}
				}
			}
			for (int i = 0; i < d.taskNum + d.stockNum; i++) {
				for (int j = 0; j < d.taskNum; j++) {
//					if (i != j) {
						// model.add(TB[i]+ET[i]+Tran_time[i][j]-TB[j]<=(1-X[i][j])*M);
						// model.add(y[i] +T[i] - Z[i][j]<=(1-X[i][j])M)
						cplex.addLe(cplex.diff(cplex.sum(Z[i][j + d.stockNum], transTime[i][j + d.stockNum]), Y[j]),
								cplex.prod(M, cplex.diff(1, X[i][j + d.stockNum]))//
						);

//					}
				}
			}

			// 对于司机的工作时间约束
			int[] arrC = new int[d.taskNum];
			for (int i = 0; i < d.taskNum; i++) {
				arrC[i] = i;
			}

			Set<Set<Integer>> subSet = ComputeUtil.getSubSet(arrC);// 包含空集
			for (Set<Integer> s : subSet) {
				if (s.size() != 0) {
				// 几个集合几个约束
					IloNumExpr[] z00 = new IloNumExpr[s.size()];
					IloNumExpr[] z11 = new IloNumExpr[s.size()];
					IloNumExpr[] z22 = new IloNumExpr[s.size()];
					int sIndex = 0;
					for (int indexInS : s) {
						IloNumExpr[] z0 = new IloNumExpr[d.stockNum];
						IloNumExpr[] z1 = new IloNumExpr[d.stockNum];
						for (int i = 0; i < d.stockNum; i++) {
							z0[i] = cplex.sum(Z[indexInS + d.stockNum][i], 
											cplex.prod(transTime[indexInS + d.stockNum][i], X[indexInS + d.stockNum][i])
											);
									
							z1[i] = Z[i][indexInS+d.stockNum];

						}
						IloNumExpr[] z2 = new IloNumExpr[s.size()];
						int index = 0;
						for (int inInS : s) {
							z2[index] = X[indexInS + d.stockNum][inInS + d.stockNum];
							index++;
						}

						z00[sIndex] = cplex.sum(z0);
						z11[sIndex] = cplex.sum(z1);
						z22[sIndex] = cplex.sum(z2);
						sIndex++;

					}

					cplex.addLe(cplex.diff(cplex.sum(z00), cplex.sum(z11)),
							cplex.sum(d.tMax, cplex.prod(Integer.MAX_VALUE, cplex.diff(s.size() - 1, cplex.sum(z11)))));
				}
				// 添加
			}

			
			// 对zij的约束
			for (int i = 0; i < d.stockNum; i++) {
				for (int j = 0; j < d.taskNum; j++) {
					cplex.addLe(Z[i][j + d.stockNum], cplex.prod(M, X[i][j + d.stockNum]));
					cplex.addLe(cplex.prod(-1, Z[j + d.stockNum][i]), cplex.prod(M, X[j + d.stockNum][i]));

				}
			}

			/**
			 * 模型求解
			 */
			// 最小化目标函数
			cplex.addMaximize(exprObj);
			// 获取求解时间
			long startTime = System.currentTimeMillis();
			Boolean solveSuccess = cplex.solve();
			long endTime = System.currentTimeMillis();
			double time = endTime - startTime;

			if (solveSuccess) {
				System.out.println("-----------1、求解状态----------");
				System.out.println("Solution status: " + cplex.getStatus() + "|||" + cplex.getAlgorithm());

				double[] values = cplex.getValues(Y);
				int k = 0;
				for (double i : values) {
					System.out.println("y" + k + "=" + Math.round(i));
					k++;
				}

				double[][] x = new double[d.stockNum + d.taskNum][d.stockNum + d.taskNum];
				double[] y = new double[d.taskNum];
				double[][] z = new double[d.stockNum + d.taskNum][d.stockNum + d.taskNum];
				for (int i = 0; i < d.stockNum + d.taskNum; i++) {
					for (int j = 0; j < d.stockNum + d.taskNum; j++) {
						if (i != j) {
							x[i][j] = cplex.getValue(X[i][j]);

							// System.out.println(cplex.getValue(X[i][j]));
							z[i][j] = cplex.getValue(Z[i][j]);
						}
					}
				}
				System.out.println("-----------2、求解时间----------");
				System.out.println("The total time is " + cplex.getObjValue());
				//
				// 0是堆场。其余是客户。
				System.out.println("-------------3、路径-------------");
				for (int i = 0; i < d.stockNum + d.taskNum; i++) {
					for (int j = 0; j < d.stockNum + d.taskNum; j++) {
						if ((i != j) && (x[i][j] == 1)) {
							// if ((i != j) ) {
							System.out.println(i + "--" + j);
						}
					}
				}

				System.out.println("-------------4、解-------------");

				for (int i = 0; i < d.stockNum + d.taskNum; i++) {
					for (int j = 0; j < d.stockNum + d.taskNum; j++) {
						System.out.println("x[" + i + "]" + "[" + j + "]" + "=" + x[i][j]);
						System.out.println("z[" + i + "]" + "[" + j + "]" + "=" + z[i][j]);
					}
				}
			}

			System.out.println("-------------5、转换时间-------------");

			for (int i = 0; i < d.stockNum + d.taskNum; i++) {
				for (int j = 0; j < d.stockNum + d.taskNum; j++) {
					System.out.println("transtime[" + i + "][" + j + "]" + "=" + transTime[i][j]);
				}
			}

			System.out.println("-------------6、节点活动时间-------------");

			for (int j = 0; j < d.taskNum; j++) {

				for (int i = 0; i < 2; i++) {
					System.out.print("[" + i + "][" + j + "]" + "=" + nodeTW[i][j] + "\t");
				}
			}

			cplex.end();
		} catch (Exception e) {

			e.printStackTrace();

		}

		System.out.println("cplexUtil执行");

	}

}
