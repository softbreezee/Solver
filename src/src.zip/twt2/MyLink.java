package twt2;


/**
 * 遍历集合中的任意一个子集
 * 例如｛012｝
 * 子集有
 * @author Leon
 *
 */
public class MyLink {
	public Node head;
	public Node curr = head;
	//插入操作
	public void addNode(int  data){
		Node node = new Node(data);
		if(head == null){
			head = node;
		}else{
			curr.next = node;
		}
		curr = node;
	}
	
	
	//删除操作
	public void delete(int index){
		Node node = head;
		int j = 0;
		while(node!=null&&j<index-2){
			//查找到第i-1个元素
			node = node.next;
			j++;
		}
		node.next = node.next.next;
		
	}
	
	
	//数据结构
	class Node{
		int data;//数据域
		Node next;//的指针域
		
		public Node(int data){
			this.data = data;
		}
	}
	


}
