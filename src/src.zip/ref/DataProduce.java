package ref;

import java.util.Date;
import java.util.List;
import java.util.Map;


public class DataProduce {
	
	
	public Example create(String name, int IE, int OE, int IF, int OF,
			int clientNum, int portNum, int stockNum, String carNum) {
		// 1、创建算例
		// 2、根据对应的数据生成map
		// 3、将对应的数据保存在数据库中
		Example ep = new Example();
		ep.setDate(new Date());
		ep.setEname(name);
		//创建集合的过程在创建算例的时候创建！
		List<Task> tasks = ep.getTasks();
		List<Site> sites = ep.getSites();

		Map<String, Object> condition = RandomCreate.getCondition(IE, OE, IF,
				OF, clientNum, portNum, stockNum, 30000, 30000);
		int[][] clientP = (int[][]) condition.get("clientPosition");
		int[][] portP = (int[][]) condition.get("portPosition");
		int[][] stockP = (int[][]) condition.get("stockPosition");
//		double[][] distance = (double[][]) condition.get("distance");
//		int[][] driveTime = (int[][]) condition.get("driveTime");
		int[][] tw1 = (int[][]) condition.get("tw1");
		int[][] tw2 = (int[][]) condition.get("tw2");
		int[] loadTime = (int[]) condition.get("loadTime");
		int[] car = ArrStrHandler.handleCar(carNum);
		// 保存site
		for (int i = 0; i < portNum; i++) {
			Site site = new Site();
			site.setPosition(portP[0][i] + "," + portP[1][i]);
			site.setType("port");
			sites.add(site);
			System.out.println("======1");
		}

		for (int i = 0; i < stockNum; i++) {
			Site site = new Site();
			site.setPosition(stockP[0][i] + "," + stockP[1][i]);
			site.setType("stock");
			site.setCarNum(car[i]);
			sites.add(site);
			System.out.println("======1");
		}

		for (int i = 0; i < clientNum; i++) {
			Site site = new Site();
			site.setPosition(clientP[0][i] + "," + clientP[1][i]);
			site.setType("client");
			sites.add(site);
			System.out.println("======1");
		}

		// 保存task
		// 空箱任务不指定堆场！堆场与客户之间是优化出来的结果！
		for (int i = 0; i < IE; i++) {
			Task task = new Task();
			task.setTaskType("IE");
			task.setTw1(tw1[0][i] + "," + tw1[1][i]);
			tasks.add(task);
		}
		for (int i = 0; i < OE; i++) {
			Task task = new Task();
			task.setTaskType("OE");
			task.setTw1(tw1[0][i + IE] + "," + tw1[1][i + IE]);
			tasks.add(task);
		}
		for (int i = 0; i < IF; i++) {
			Task task = new Task();
			task.setTaskType("IF");
			task.setTw1(tw1[0][i + IE + OE] + "," + tw1[1][i + IE + OE]);
			task.setTw2(tw2[0][i] + "," + tw2[1][i]);
			task.setLoadTime(loadTime[i]);
			tasks.add(task);
		}
		for (int i = 0; i < OF; i++) {
			Task task = new Task();
			task.setTaskType("OF");
			task.setTw1(tw1[0][i + IE + OE + IF] + "," + tw1[1][i + IE + OE + IF]);
			task.setTw2(tw2[0][i + IF] + "," + tw2[1][i + IF]);
			task.setLoadTime(loadTime[i + IF]);
			tasks.add(task);
		}

		// 任务与地理位置的组合！！
		for (int i = 0; i < IE; i++) {
			/**
			 * 进口空箱，从港口到堆场！ 这里只指定港口，堆场是优化的目标！
			 */
			int portIndex = (int) (Math.random() * portNum);
			Site start = sites.get(portIndex);
			tasks.get(i).setStart(start);
		}
		for (int i = 0; i < OE; i++) {
			/**
			 * 出口空箱，从堆场到港口 这里同样只指定出口的港口！！
			 */
			int portIndex = (int) (Math.random() * portNum);
			Site end = sites.get(portIndex);
			tasks.get(i+IE).setEnd(end);
		}
		for (int i = 0; i < IF; i++) {
			/**
			 * 重箱的任务与客户点的顺序一一对应！港口随机分配到
			 * 进口重箱，港口——》客户 ；港口不指定，客户按顺序分配！
			 */
//			int portIndex = (int) (Math.random() * portNum);
//			Site start = sites.get(portIndex);
			Site end = sites.get(i + portNum + stockNum);
//			tasks.get(i + IE + OE).setStart(start);
			tasks.get(i + IE + OE).setEnd(end);
		}
		for (int i = 0; i < OF; i++) {
			/**
			 * 出口重箱，客户——》港口 ；港口随机不指定，客户按顺序分配！
			 */
//			int portIndex = (int) (Math.random() * portNum);
			// int clientIndex = (int) (Math.random()*clientNum);
			// 客户点的数量 == 重箱任务的数量？
			Site start = sites.get(i + portNum + stockNum + IF);
//			Site end = sites.get(portIndex);
			tasks.get(i + IE + OE + IF).setStart(start);
//			tasks.get(i + IE + OE + IF).setEnd(end);
		}

		// 对与满箱任务，港口随机分配，客户随机分配
		//exampleDao.save(ep);

		return ep;
	}

}
